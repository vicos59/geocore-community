<?php

if (!defined('IN_GEO_API')) {
    exit('No access.');
}
//This is a simple API function.  All it does, is return the arguments
//that were passed to it.  This is mainly for testing purposes.
return $args;
