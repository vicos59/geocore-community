<?php

/* This was used by the super-old "registration filters," which are removed entirely as of 7.3.0 */
