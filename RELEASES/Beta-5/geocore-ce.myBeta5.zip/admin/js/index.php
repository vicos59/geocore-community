<?php

echo "access denied";
