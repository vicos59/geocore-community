/**
 * These settings are used by various JS scripts used on the 
 * admin side.
 * 
 */


//Set this to the duration all javascript animations use,
//set to 0 to effectively turn off animations.  Default 
//is .5 (half a second)

var defaultDuration = .5;
