<?php

//This order item is not used anymore. Listings are now associated with regions directly by the core software and not this addon.
