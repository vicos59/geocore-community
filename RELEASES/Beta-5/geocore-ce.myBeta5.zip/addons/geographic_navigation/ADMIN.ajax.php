<?php

//geographic_navigation/ADMIN.ajax.php

if (class_exists('admin_AJAX') or die()) {
}

//this file no longer used
