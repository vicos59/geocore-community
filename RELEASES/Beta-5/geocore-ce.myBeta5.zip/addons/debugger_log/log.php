<?php

//addons/debugger_log/log.php
/*
This file will be used to add log messages to.
You will need to CHMOD this file to 777 (or make
it so that the PHP script has the proper permission
to write to the file)

NOTICE: It is important to LEAVE THIS HEADER,
or it will make the script vulnerable to different attacks.
##_____________LOG MESSAGES START_____________##
