<?php

class addon_anonymous_listing_pages
{
    public function anon_pass()
    {
        //This page should not be visited directly, go ahead and display
        return 'Page used internally only.';
    }
}
